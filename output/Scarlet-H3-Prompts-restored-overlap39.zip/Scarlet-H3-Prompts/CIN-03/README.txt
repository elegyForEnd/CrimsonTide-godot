CIN-03 医疗记录
触发：R-1-04，唯一血晶取出且照明角度正确
状态：只有一次诊疗的固定机位记录；女王清醒批准秘密处置。影像不能读心或切到现场未拍到的位置。
落点：影像熄灭，回到礼拜堂三人，绯月握紧手指。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
<Picture 4>：女王 → assets/bosses/blood-queen-portrait.png
<Picture 5>：医师 → assets/story/scarlet/npc/physician-v2.png
备注：无额外后期台词；以相邻 ADV 为准。

原版恢复＋39 帧接续：下列为实际生成窗口（终帧不含），原剪辑秒数不直接作为生成时长。
GEN1: [0,124)，生成 124 帧／5.166667 秒，重复 0 帧。
GEN2: [85,294)，生成 209 帧／8.708333 秒，重复 39 帧。
GEN3: [255,464)，生成 209 帧／8.708333 秒，重复 39 帧。
GEN4: [425,600)，生成 175 帧／7.291667 秒，重复 39 帧。

# 剧本制作文件

完整剧本：docs/rpg/SCARLET-FULL-SCREENPLAY.md

任务接取与推进：quest-intake.csv
场景触发与演出：scene-cues.csv
对白录音清单：dialogue-recording.csv
逐场原始数据：screenplay.json

所有内容为新制作脚本，未接入运行，不包含声音、影片或新增图像。

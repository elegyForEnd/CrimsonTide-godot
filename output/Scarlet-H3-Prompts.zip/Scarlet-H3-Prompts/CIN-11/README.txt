CIN-11 让船通过
触发：R-5-06，提督败、缆弩解除、锁舵且民船释放后
状态：所有解锁操作已成功；本片只展示它们的结果。控制船不能撞沉，难民先撤。
落点：三人在安全甲板看民船离开，再回码头。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
<Picture 4>：船长 → assets/story/scarlet/npc/captain.png
备注：无额外后期台词；以相邻 ADV 为准。

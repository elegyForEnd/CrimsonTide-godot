CIN-06B 山门伏击·未勘查
触发：R-3-02，ambush_prepared=false
状态：编号按运行代码：B 是未准备。没有侧梯；雪璃仅被隔开，后续固定路线抓捕不在本片演完。
落点：雪璃在隔开的高台护伤者，绯月和鸦羽准备切近处索；交还下层操作。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
<Picture 4>：维恩 → assets/story/scarlet/npc/vein.png
备注：无额外后期台词；以相邻 ADV 为准。

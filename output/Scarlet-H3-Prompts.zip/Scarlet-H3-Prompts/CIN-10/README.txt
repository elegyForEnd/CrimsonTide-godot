CIN-10 封港舰队
触发：R-5-03，工事望台主动查看
状态：黑帆舰队封住海口，提督要求绯月独自登船；押运仓还没有由玩家调查。
落点：三人在望台看见炮口，进入传话 ADV，不自动登舰。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
<Picture 4>：提督·莫罗 → assets/story/scarlet/npc/admiral.png
备注：无额外后期台词；以相邻 ADV 为准。

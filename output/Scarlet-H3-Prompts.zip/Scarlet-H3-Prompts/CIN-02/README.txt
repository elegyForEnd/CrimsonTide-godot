CIN-02 雾桥上的三个人
触发：R-1-04，玩家修好桥索并确认过桥
状态：中央桥面与桥索已修好，可以通行；绯月前、雪璃中、鸦羽后。
落点：三人全部抵达完整南平台，礼拜堂箱子尚未打开。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
备注：无额外后期台词；以相邻 ADV 为准。

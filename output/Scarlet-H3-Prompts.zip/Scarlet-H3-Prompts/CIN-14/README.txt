CIN-14 双剑与侧廊的光
触发：女王战阶段一结束、伤害模拟停止后
状态：女王尚未败，六翼仍在；绯月与女王交锁后退开，雪璃与鸦羽从侧廊汇合，不自动破坏翼根。
落点：三人面向女王站稳，进入阶段二。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：女王 → assets/bosses/blood-queen-portrait.png
<Picture 3>：雪璃 → assets/xueli.png
<Picture 4>：鸦羽 → assets/yayu.png
备注：无额外后期台词；以相邻 ADV 为准。

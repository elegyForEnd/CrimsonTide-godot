CIN-12 主动驶向王城
触发：R-5-06，返码头并明确选现在前往王城
状态：三人自由同行，主动出发；绯月剑柄已拆外饰但契印仍完整，不戴镣铐。
落点：王城旧水门登陆台，接玩家潜入准备。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
<Picture 4>：船长 → assets/story/scarlet/npc/captain.png
备注：无额外后期台词；以相邻 ADV 为准。

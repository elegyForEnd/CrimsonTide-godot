CIN-15 继位仪式
触发：女王战阶段二完成，三组翼根已解除
状态：女王王冠开裂，六翼已受损失能，不能恢复六片完整翼。女王主动开启仪式；母晶第一次完全暴露。
落点：剑尖停在心口外，尚未刺入；交还阶段三反制操作。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：女王 → assets/bosses/blood-queen-portrait.png
备注：无额外后期台词；以相邻 ADV 为准。

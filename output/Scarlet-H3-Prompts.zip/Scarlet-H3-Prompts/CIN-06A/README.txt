CIN-06A 山门伏击·已准备
触发：R-3-02，ambush_prepared=true
状态：编号按运行代码：A 是已勘查。侧梯已预布，雪璃不会在本片被绑或被俘。
落点：雪璃和伤者进矿坑备路，绯月与鸦羽留在下层入口。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
<Picture 4>：维恩 → assets/story/scarlet/npc/vein.png
备注：原制作表把 A/B 写反，本包以 scripts/scarlet/campaign.gd 的实际分支为准。前两镜可与 06B 共用。

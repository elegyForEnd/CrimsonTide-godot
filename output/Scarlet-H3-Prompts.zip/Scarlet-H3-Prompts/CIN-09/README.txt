CIN-09 越过海堤的红潮
触发：R-5-02，玩家到等船观察点
状态：回程船已修好并保持可用；潮灾发生在上游与低洼街区，七名幸存者后续由玩家救。
落点：三人到救援入口高地，未自动救完任何人。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
备注：无额外后期台词；以相邻 ADV 为准。

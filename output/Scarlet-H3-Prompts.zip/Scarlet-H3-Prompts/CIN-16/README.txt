CIN-16 三人奥义与断剑
触发：阶段三稳场、断扣、母晶破防已完成，玩家确认共同终结
状态：三人执行已经争取到的终结机会。母晶、王冠、继位契印三者都必须毁掉；女王只在独立镜头出现，仍活着等最后选择。
落点：断剑契印熄灭，女王在开裂侧台呼吸，回安全 ADV 做最终选择。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
<Picture 4>：女王 → assets/bosses/blood-queen-portrait.png
备注：母晶、王冠、契印分别有独立可读镜头。最后仍未替玩家选择救援。破损剑在 CIN-17/18 与 CG-16B 中统一沿用斜裂赤晶＋半截旧金护手形状。

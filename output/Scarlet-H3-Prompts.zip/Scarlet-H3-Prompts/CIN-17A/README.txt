CIN-17A 终局撤离·绳索救援
触发：最终选择：救女王并确认
状态：女王重伤存活，已失冠与六翼，不能自愈或飞行；主线退路与绳锚已准备好。
落点：女王被医护与看守接手；主角三人可前往外墙观景点。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
<Picture 4>：女王 → assets/bosses/blood-queen-portrait.png
备注：无额外后期台词；以相邻 ADV 为准。

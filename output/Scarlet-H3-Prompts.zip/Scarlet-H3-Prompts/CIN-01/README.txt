CIN-01 窗外的第二组弩手
触发：R-P01，信使推开绯月的瞬间
状态：雨夜客舍，信使带来的遗书已在桌上，追缉令仍未展开。信使负伤但存活，鸦羽从门侧入场。
落点：雪璃扶住信使、绯月护窗、鸦羽稳住遮挡物，返回伤者旁 ADV。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
<Picture 4>：信使 → assets/story/scarlet/npc/messenger.png
备注：无额外后期台词；以相邻 ADV 为准。

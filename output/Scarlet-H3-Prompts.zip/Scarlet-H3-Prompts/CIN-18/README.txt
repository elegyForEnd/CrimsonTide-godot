CIN-18 废墟黎明
触发：两条撤离线之一完成，玩家到外墙观景点确认
状态：共同结尾仅三人；王城仍是废墟，风暴消退不是建筑复原。绯月携带破损剑与断柄，契印已灭。
落点：同机位外墙安全观景点，淡回游戏，玩家仍需走回旧水门。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：雪璃 → assets/xueli.png
<Picture 3>：鸦羽 → assets/yayu.png
备注：无额外后期台词；以相邻 ADV 为准。

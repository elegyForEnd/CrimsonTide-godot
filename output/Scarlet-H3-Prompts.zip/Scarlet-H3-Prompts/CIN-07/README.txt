CIN-07 交易失败
触发：第四章鸦羽视角幕间 ADV 后
状态：鸦羽独自带绯月的剑谈判失败；她自己的完整长刀由近卫暂时控制。女王将返回王城，瑟芮留守行宫。
落点：鸦羽与封存剑箱被押往行宫；女王的船离开。接绯月清晨追踪。
参考图上传顺序：
<Picture 1>：鸦羽 → assets/yayu.png
<Picture 2>：女王 → assets/bosses/blood-queen-portrait.png
<Picture 3>：缀身夫人·瑟芮 → assets/story/scarlet/npc/surgeon.png
备注：无额外后期台词；以相邻 ADV 为准。

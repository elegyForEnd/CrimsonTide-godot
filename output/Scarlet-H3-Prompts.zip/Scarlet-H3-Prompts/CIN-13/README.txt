CIN-13 六翼与妹妹
触发：R-6-05，绯月拒绝刺心后
状态：初始女王恰好完整六翼，左右各三；雪璃与鸦羽在侧道，不在主厅。绯月剑柄外饰已拆并有防护包裹，契印未断。
落点：绯月左、女王右，相距足够开战，两把不同的剑各归本人。
参考图上传顺序：
<Picture 1>：绯月 → assets/feiyue.png
<Picture 2>：女王 → assets/bosses/blood-queen-portrait.png
备注：无额外后期台词；以相邻 ADV 为准。
